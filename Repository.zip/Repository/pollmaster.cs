﻿using poll_api.Controllers;
using poll_api.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace poll_api.Repository
{
    public class pollmaster
    {
        public userVm ValidateUser(string userName, string password)
        {
            try
            {
                userVm data = null;
                using (var db = new vplnet_Entities())
                {
                    data = (from a in db.UserMs
                            where a.UserName.ToLower() == userName.ToLower()
                            &&
                            a.Password == password
                            select new userVm
                            {
                                UserName = a.UserName,
                                IsAdmin = a.IsAdmin,
                                IsFirstTimeLogin = a.IsFirstTimeLogin,
                                UserID = a.UserID,
                                Name = a.Name,
                                BalanceCredit = a.BalanceCredit,
                                BalanceMessage = ""
                            }).FirstOrDefault();

                }
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public string GetBalanceCredits(int userId)
        {
            using (var db = new vplnet_Entities())
            {
                return db.UserMs.FirstOrDefault(x => x.UserID == userId)?.BalanceCredit.ToString();
            }
        }
        public List<PollMaster> GetPolls(int userId)
        {
            using (var db = new vplnet_Entities())
            {


                var result = (from x in db.PollMs.ToList()
                              where

 x.PollStatus != "Completed" &&
 DateTime.Now > x.DisplayStartTime &&
 DateTime.Now < x.DisplayEndTime

                              join y in db.PollAnswers.ToList()
                                      on x.PollId equals y.PollId into ps
                              from y in ps.Where(f => f.UserId == userId).DefaultIfEmpty()
                              join userTrans in db.UserTransactions
                              on x.PollId equals userTrans.PollID into userAmount
                              from rrr in userAmount.Where(f => f.UserID == userId).DefaultIfEmpty()

                              select new PollMaster
                              {
                                  UserId = userId,
                                  IsArrowMark = false,
                                  PollId = x.PollId,
                                  PollName = x.PollName,
                                  StartTime = x.StartTime,
                                  EndTime = x.EndTime,
                                  PollAns = x.PollAns,
                                  UserPollAns = y != null ? y.PollAns : null,
                                  Option1 = x.Option1,
                                  Option1Percent = GetPercentage(x.PollId, x.Option1),
                                  Option2 = x.Option2,
                                  Option2Percent = GetPercentage(x.PollId, x.Option2),
                                  Option3 = x.Option3,
                                  PollOrder = x.PollOrder,
                                  PollStatus = x.PollStatus,
                                  DisplayStartTime = x.DisplayStartTime,
                                  DisplayEndTime = x.DisplayEndTime,
                                  BetAmount = x.BetAmount,
                                  UserBetAmount = y != null ? y.BetAmount : 0.00,
                                  BetAmountMin = x.BetAmountMin,
                                  MatchResult = x.MatchResult,
                                  CreditDebitAmount = rrr != null ? rrr.CreditDebitAmount : 0.00,
                                  TransactionType = rrr != null ? rrr.TransactionType : -1,
                                  PollOptions = x.PollOptions.Select(p => new PollOptions() { PollId = x.PollId, PollOption1 = p.PollOption1, PollOptionId = p.PollOptionId, DisplayOrder = p.DisplayOrder }).ToList()
                              }).OrderBy(x => x.PollOrder).ToList();

                //var result = db.PollMs.ToList().Select(x => new PollMaster()
                //{
                //    IsArrowMark = false,
                //    PollId = x.PollId,
                //    PollName = x.PollName ,
                //    StartTime = x.StartTime,
                //    EndTime = x.EndTime,
                //    PollAns = x.PollAns,
                //    Option1 = x.Option1,
                //    Option2 = x.Option2,
                //    Option3 = x.Option3,
                //    PollOrder = x.PollOrder,
                //    PollStatus = x.PollStatus,
                //    DisplayStartTime = x.DisplayStartTime,
                //    DisplayEndTime = x.DisplayEndTime,
                //    BetAmount = x.BetAmount,
                //    BetAmountMin = x.BetAmountMin,
                //    PollOptions = x.PollOptions.Select(p => new PollOptions() { PollId = x.PollId, PollOption1 = p.PollOption1, PollOptionId = p.PollOptionId, DisplayOrder = p.DisplayOrder }).ToList()
                //}).OrderBy(x => x.PollOrder).ToList();
                return result;
            }
        }
        public List<PollMaster> GetPollResult(int userId)
        {
            using (var db = new vplnet_Entities())
            {


                var result = (from x in db.PollMs.ToList()
                              where
                              x.PollStatus == "Completed" && x.PollId != 1

                              join y in db.PollAnswers.ToList()
                                      on x.PollId equals y.PollId into ps
                              from y in ps.Where(f => f.UserId == userId).DefaultIfEmpty()
                              join userTrans in db.UserTransactions
                              on x.PollId equals userTrans.PollID into userAmount
                              from rrr in userAmount.Where(f => f.UserID == userId).DefaultIfEmpty()

                              select new PollMaster
                              {
                                  UserId = userId,
                                  IsArrowMark = false,
                                  PollId = x.PollId,
                                  PollName = x.PollName,
                                  StartTime = x.StartTime,
                                  EndTime = x.EndTime,
                                  PollAns = x.PollAns,
                                  UserPollAns = y != null ? y.PollAns : null,
                                  Option1 = x.Option1,
                                  Option1Percent = GetPercentage(x.PollId, x.Option1),
                                  Option2 = x.Option2,
                                  Option2Percent = GetPercentage(x.PollId, x.Option2),
                                  Option3 = x.Option3,
                                  PollOrder = x.PollOrder,
                                  PollStatus = x.PollStatus,
                                  DisplayStartTime = x.DisplayStartTime,
                                  DisplayEndTime = x.DisplayEndTime,
                                  BetAmount = x.BetAmount,
                                  UserBetAmount = y != null ? y.BetAmount : 0.00,
                                  BetAmountMin = x.BetAmountMin,
                                  MatchResult = x.MatchResult,
                                  CreditDebitAmount = rrr != null ? rrr.CreditDebitAmount : 0.00,
                                  TransactionType = rrr != null ? rrr.TransactionType : -1,
                                  PollOptions = x.PollOptions.Select(p => new PollOptions() { PollId = x.PollId, PollOption1 = p.PollOption1, PollOptionId = p.PollOptionId, DisplayOrder = p.DisplayOrder }).ToList()
                              }).OrderByDescending(x => x.PollOrder).ToList();

                return result;
            }
        }

        public double GetPercentage(int pollId, string Opt)
        {
            double percentage = 0;
            using (var db = new vplnet_Entities())
            {
                int OptCount = db.PollAnswers.Where(x => x.PollId == pollId && x.PollAns == Opt).Count();
                int TotalCount = db.PollAnswers.Where(x => x.PollId == pollId).Count();
                if (TotalCount == 0)
                {
                    percentage = 50;
                }
                else
                {
                    if (OptCount == 0)
                    {
                        percentage = 0;
                    }
                    else
                    {
                        percentage = (int)Math.Round(((double)OptCount / (double)TotalCount) * 100);
                    }

                }

                return percentage;
            }

        }
        public string UpdatePoll(int pollId, int userId, string answer, double? betAmount)
        {
            using (var db = new vplnet_Entities())
            {
                var pollAns = db.PollAnswers.FirstOrDefault(x => x.PollId == pollId && x.UserId == userId);
                if (pollAns != null)
                {
                    db.PollAnswers.Remove(pollAns);
                }
                db.PollAnswers.Add(new PollAnswer()
                {
                    PollAns = answer,
                    PollId = pollId,
                    UserId = userId,
                    PollTime = DateTime.Now,
                    BetAmount = betAmount
                });
                db.SaveChanges();
                return "Voted Successfully";
            }
        }
        public void ErrorLog(string LogHead, string Description, int UserId)
        {
            using (var db = new vplnet_Entities())
            {

                db.ErrorLogs.Add(new ErrorLog()
                {
                    LogHead = LogHead,
                    UserId = UserId,
                    CreatedDate = DateTime.Now,
                    Description = Description
                });
                db.SaveChanges();

            }
        }
        public void ActionLog(string LogHead, string Description, int UserId)
        {
            using (var db = new vplnet_Entities())
            {

                db.Logs.Add(new Log()
                {
                    LogHead = LogHead,
                    UserId = UserId,
                    CreatedDate = DateTime.Now,
                    Description = Description
                });
                db.SaveChanges();

            }
        }
        public List<sp_GetRanksByNoOFWin_Result> GetTopRanks()
        {
            using (var db = new vplnet_Entities())
            {
                return db.sp_GetRanksByNoOFWin().ToList();
            }
        }
        public double GetEffectiveBalance(int userId, int pollId)
        {
            List<sp_GetUserEffectiveBalance_Result> value;
            using (var db = new vplnet_Entities())
            {
                value = db.sp_GetUserEffectiveBalance(userId, pollId).ToList();
            }

            return value.Count == 0 ? 0 : (value.FirstOrDefault()?.BalanceAmount ?? 0);
        }
        public string GetMatchStatus(int pollId)
        {

            using (var db = new vplnet_Entities())
            {
                return db.PollMs.Where(x => x.PollId == pollId).FirstOrDefault().PollStatus;
            }


        }
        public bool ResetPassword(string userName, string name, string password, string YourFavourateTeam)
        {
            using (var db = new vplnet_Entities())
            {
                var user = db.UserMs.FirstOrDefault(x => x.UserName == userName);
                if (user != null)
                {
                    user.Password = password;
                    user.IsFirstTimeLogin = true;
                    user.YourFavourateTeam = YourFavourateTeam;
                    user.Name = name;
                    user.Image = userName + ".jpg";
                    db.SaveChanges();
                }
            }
            return true;
        }
        public string RegisterUser(string userName, string name, string password, string YourFavourateTeam)
        {
            string msg = string.Empty;
            using (var db = new vplnet_Entities())
            {
                var usr = db.UserMs.FirstOrDefault(x => x.UserName == userName);
                if (usr == null)
                {
                    var user = new UserM();
                    user.UserName = userName;
                    user.Password = password;
                    user.IsAdmin = false;
                    user.IsFirstTimeLogin = true;
                    user.Name = name;
                    user.Image = null;
                    user.YourFavourateTeam = YourFavourateTeam;
                    user.BalanceCredit = 1000;
                    db.UserMs.Add(user);
                    db.SaveChanges();

                    var creditedAmount = new UserCredit();
                    creditedAmount.AddedUserId = 1;
                    creditedAmount.Credit = 1000;
                    creditedAmount.CreditDate = DateTime.Now;
                    creditedAmount.UserID = user.UserID;
                    db.UserCredits.Add(creditedAmount);
                    db.SaveChanges();
                    msg = "User added !";
                }
                else
                {
                    msg = "User already exists !";
                }
            }
            return msg;
        }
        public bool ChangePassword(string userName, string password)
        {
            using (var db = new vplnet_Entities())
            {
                var user = db.UserMs.FirstOrDefault(x => x.UserName == userName);
                if (user != null)
                {
                    user.Password = password;
                    db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
        public string AddNewUser(string userName, double amount)
        {
            string msg = string.Empty;
            using (var db = new vplnet_Entities())
            {
                var usr = db.UserMs.FirstOrDefault(x => x.UserName == userName);
                if (usr == null)
                {
                    var user = new UserM();
                    user.UserName = userName;
                    user.Password = "1";
                    user.IsAdmin = false;
                    user.IsFirstTimeLogin = false;
                    user.Name = null;
                    user.Image = null;
                    user.YourFavourateTeam = null;
                    user.BalanceCredit = amount;
                    db.UserMs.Add(user);
                    db.SaveChanges();
                    msg = "User added !";
                }
                else
                {
                    msg = "User already exists !";
                }
            }
            return msg;
        }
        public string UpdateBalanceAmount(string userName, double amount)
        {
            string msg = string.Empty;
            using (var db = new vplnet_Entities())
            {
                var user = db.UserMs.FirstOrDefault(x => x.UserName == userName);
                if (user != null)
                {
                    user.BalanceCredit = amount;
                    db.SaveChanges();
                    msg = "Balance Updated !";
                }
                else
                {
                    msg = "User not exists !";
                }
            }
            return msg;
        }
        public void ProcessPoll(int pollId)
        {
            using (var db = new vplnet_Entities())
            {
                db.sp_processpoll(pollId);
                db.SaveChanges();
            }
        }
        public List<GetActivePollAnswers_CommaSeparated_Vm> GetAnswers(int userId, int pollId)
        {
            using (var db = new vplnet_Entities())
            {
                var d = db.sp_GetActivePollAnswers_CommaSeparated_ByPollId(userId, pollId).ToList().Select(x =>
                new GetActivePollAnswers_CommaSeparated_Vm()
                {
                    PollAns = x.PollAns,
                    PollId = x.PollId,
                    PollName = x.PollName,
                    PollStatus = x.PollStatus,
                    TotalVotes = x.TotalVotes,
                    UserName = x.UserName
                }).ToList();
                return d;
            }
        }
        public List<GetActivePollAnswers_CommaSeparated_Vm> GetAnswersByUser(int userId, int pollId)
        {
            using (var db = new vplnet_Entities())
            {

                var d = db.sp_GetActivePollAnswers_CommaSeparated_ByPollId(userId, pollId).ToList().Select(x =>
                new GetActivePollAnswers_CommaSeparated_Vm()
                {
                    PollAns = x.PollAns,
                    PollId = x.PollId,
                    PollName = x.PollName,
                    PollStatus = x.PollStatus,
                    TotalVotes = x.TotalVotes,
                    UserName = x.UserName
                }).ToList();
                return d;
            }
        }

        public PollM GetPollDetails(int pollId)
        {
            using (var db = new vplnet_Entities())
            {
                return db.PollMs.FirstOrDefault(x => x.PollId == pollId);
            }
        }
        public string UpdatePollAnswer(int pollId, string pollAns, string pollResult)
        {
            if (string.IsNullOrEmpty(pollAns) || pollAns.Trim() == "")
            {
                pollAns = null;
            }
            var msg = "Poll Answer added successfully";
            using (var db = new vplnet_Entities())
            {
                var poll = db.PollMs.FirstOrDefault(x => x.PollId == pollId);
                poll.PollAns = pollAns;
                poll.MatchResult = pollResult;
                db.SaveChanges();

            }
            return msg;
        }
        public List<TeamsVM> GetPointTable()
        {
            using (var db = new vplnet_Entities())
            {
                var result = db.Teams.Select(x => new TeamsVM
                {
                    TeamId = x.TeamId,
                    Team = x.Team1,
                    L = x.L,
                    M = x.M,
                    NRR = x.NRR,
                    Pts = x.Pts,
                    Status = x.Status,
                    W = x.W
                }).OrderByDescending(y => y.Pts).ThenByDescending(x => x.NRR).ToList();
                return result;
            }

        }
        public List<userVm> GetAllUsers()
        {
            using (var db = new vplnet_Entities())
            {
                var openingBal = db.UserCredits.FirstOrDefault().Credit;
                var result = db.UserMs.Select(u => new userVm
                {
                    BalanceMessage = openingBal.ToString(),
                    BalanceCredit = u.BalanceCredit,
                    Name = u.Name,
                    UserID = u.UserID,
                    UserName = u.UserName,
                    YourFavourateTeam = u.YourFavourateTeam,
                    Password = u.Password
                }).ToList();
                return result;
            }


        }

        public string UpdateUser(int userId, string userName, string name, string password)
        {

            using (var db = new vplnet_Entities())
            {
                var poll = db.UserMs.FirstOrDefault(x => x.UserID == userId);
                if (poll == null)
                    return "User not exists !";
                poll.UserName = userName;
                poll.Name = name;
                poll.Password = password;
                db.SaveChanges();
                return "User details updated successfully !";
            }

        }



        public int Process_Poll_Transaction(int pollId, string pollAns, string pollResult)

        {
            using (var db = new vplnet_Entities())
            {
                using (DbContextTransaction transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        if (string.IsNullOrEmpty(pollAns) || pollAns.Trim() == "")
                        {
                            pollAns = null;
                        }

                        // update aswer to poll master table
                        var pollM = db.PollMs.FirstOrDefault(x => x.PollId == pollId);
                        pollM.PollAns = pollAns;
                        pollM.MatchResult = pollResult;
                        db.SaveChanges();
                        // update aswer to poll master table

                        // user transaction - update amount
                        var poll = (from polls in db.PollMs
                                    join opt in db.PollAnswers on polls.PollId equals opt.PollId
                                    where polls.PollId == pollId
                                    select new poll_processVM()
                                    {
                                        PollId = polls.PollId,
                                        PollName = polls.PollName,
                                        PollAns = polls.PollAns,
                                        UserId = opt.UserId,
                                        UserBetAmount = opt.BetAmount,
                                        UserPerdictedAnswer = opt.PollAns,
                                        betStatus = opt.PollAns == polls.PollAns ? 1 : 0,
                                        TransactionAmount = 0,
                                        Win_Loss_ProcessTotalAmount = 0.00

                                    }).ToList();
                        if (poll == null)
                        {
                            return -1;
                        }

                        var _winProcessTotalAmount = poll.Where(x => x.betStatus == 1).Sum(x => x.UserBetAmount);
                        var _lossProcessTotalAmount = poll.Where(x => x.betStatus == 0).Sum(x => x.UserBetAmount);
                        var effectiveBetAmount = _winProcessTotalAmount == _lossProcessTotalAmount ? _winProcessTotalAmount :
                                                 (_winProcessTotalAmount > _lossProcessTotalAmount) ? _lossProcessTotalAmount : _winProcessTotalAmount;




                        foreach (var item in poll)
                        {
                            double? yourBetAmount = item.UserBetAmount;
                            var totalBetAmount = poll.Where(x => x.betStatus == item.betStatus).Sum(x => x.UserBetAmount);
                            var v1 = yourBetAmount / totalBetAmount;
                            var percentage = v1 * 100;
                            int multiplayer = item.betStatus == 1 ? 1 : -1;
                            var number = (percentage / 100) * effectiveBetAmount;
                            item.Win_Loss_ProcessTotalAmount = (int)Math.Round((double)number * multiplayer);

                            var user = db.UserTransactions.FirstOrDefault(x => x.PollID == pollId && x.UserID == item.UserId);
                            if (user != null)
                            {
                                db.UserTransactions.Remove(user);
                                db.SaveChanges();
                            }
                            var ut = new UserTransaction();
                            ut.UserID = item.UserId;
                            ut.PollID = item.PollId;
                            ut.CreditDebitAmount = item.Win_Loss_ProcessTotalAmount;
                            ut.TransactionType = item.betStatus;
                            ut.TransactionDate = DateTime.Now;
                            db.UserTransactions.Add(ut);
                            db.SaveChanges();

                        }

                        // update user balance in user table
                        db.sp_UpdateUserBalance();

                        transaction.Commit();
                        return 1;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        return -1;
                    }
                }
            }
        }


        public List<PollMaster> GetFixture()
        {
            using (var db = new vplnet_Entities())
            {

                var result = db.PollMs.Where(x=> x.PollStatus != "Completed").ToList().Select(x => new PollMaster()
                {
                    IsArrowMark = false,
                    PollId = x.PollId,
                    PollName = x.PollName,
                    StartTime = x.StartTime,
                    EndTime = x.EndTime,
                    PollAns = x.PollAns,
                    Option1 = x.Option1,
                    Option2 = x.Option2,
                    Option3 = x.Option3,
                    PollOrder = x.PollOrder,
                    PollStatus = x.PollStatus,
                    DisplayStartTime = x.DisplayStartTime,
                    DisplayEndTime = x.DisplayEndTime,
                 
                   
                }).OrderBy(x => x.PollOrder).ToList();
                return result;
            }
        }

        //Status 
        //    1=Active , 2= Pending for approval ,0 inactive ,3= ready for auction
        public int RegisterPlayer(Player player)
        {
          
            using (var db = new vplnet_Entities())
            {
                var usr = db.Players.FirstOrDefault(x => x.Phone == player.Phone);
                if (usr == null)
                {
                    var p = new Player();
                    p.PlayerName = player.FirstName+" "+player.LastName;
                    p.FirstName = player.FirstName;
                    p.LastName = player.LastName;
                    p.Location = player.Location;
                    p.Dob = player.Dob;
                    p.Phone = player.Phone;
                    p.Role = player.Role;
                    p.Batting = player.Batting;
                    p.Bowling = player.Bowling;
                    p.ProfilePic = player.ProfilePicName;
                    p.Proof = player.Proof;
                    p.CreatedDate = DateTime.Now;
                    p.IsActive = false;
                    p.Status = 2;
                    db.Players.Add(p);
                    db.SaveChanges();
                    return p.Pid;
                }
                else
                {
                    return 0;
                }
            }
            
        }


        public int RegisterTeam(Team1 player)
        {

            using (var db = new vplnet_Entities())
            {
                var usr = db.Team1.FirstOrDefault(x => x.TeamName == player.TeamName);
                if (usr == null)
                {
                    var p = new Team1();

                    p.TeamName = player.TeamName;
                    p.OwnerName = player.OwnerName;
                    p.Location = player.Location;
                    p.ContactNumber = player.ContactNumber;
                    p.IconPlayerName = player.IconPlayerName;
                    p.Logo = player.Logo;
                    p.IsActive = 1;
                    db.Team1.Add(p);
                    db.SaveChanges();
                    return p.TeamId;
                }
                else
                {
                    return 0;
                }
            }

        }

        public List<Player> GetPlayers()
        {
            using (var db = new vplnet_Entities())
            {

                var result = db.Players.Where(x=>x.IsActive==true).OrderBy(x=>x.Pid).ToList();
                return result;
            }
        }
        public List<Team1> GetTeams()
        {
            using (var db = new vplnet_Entities())
            {

                var result = db.Team1.ToList();
                return result;
            }
        }
        public List<PageContent> GetPageContents()
        {
            using (var db = new vplnet_Entities())
            {

                var result = db.PageContents.ToList();
                return result;
            }
        }
    }
}
public class poll_processVM
{
    public int UserId { get; set; }
    public int PollId { get; set; }
    public string PollName { get; set; }
    public string PollAns { get; set; }

    public double UserBalanceCredit { get; set; }
    public string UserPerdictedAnswer { get; set; }

    public double? UserBetAmount { get; set; }

    public int betStatus { get; set; }
    public double TransactionAmount { get; set; }
    public double? Win_Loss_ProcessTotalAmount { get; set; }
   

}