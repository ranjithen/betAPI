﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using poll_api.Repository;
using System.Web.Http;
using poll_api.Data;

namespace poll_api.Controllers 
{
    public class PollMsController : ApiController
    {
        private pollmaster db;
        public PollMsController()
        {db  = new pollmaster();
        }

        [System.Web.Http.HttpGet]
        public IHttpActionResult GetPolls(int userId)
        {
            try
            {
                
                var result = db.GetPolls(userId).ToList();
                
                return Ok(result);
            }
            catch (Exception ex)
            {
                db.ErrorLog("GetPolls", ex.Message, userId);
                throw ex;
            }
        }
        public IHttpActionResult GetFixture()
        {
            try
            {

                var result = db.GetFixture().ToList();

                return Ok(result);
            }
            catch (Exception ex)
            {
                db.ErrorLog("GetFixture", ex.Message, 0);
                throw ex;
            }
        }
        public IHttpActionResult GetPollsResult(int userId)
        {
            try
            {

                var result = db.GetPollResult(userId).ToList().OrderByDescending(x=>x.PollOrder);

                return Ok(result);
            }
            catch (Exception ex)
            {
                db.ErrorLog("GetPolls", ex.Message, userId);
                throw ex;
            }
        }
        public IHttpActionResult GetAnswers(int userId, int pollId)
        {
            try
            {

                var answers = db.GetAnswers( userId,  pollId).ToList();
                return Ok( answers );
            }
            catch (Exception ex)
            {
                db.ErrorLog("GetAnswers", ex.Message, userId);
                throw ex;
            }
        }
        public IHttpActionResult GetTopRanks()
        {
            try
            {

                var ranks = db.GetTopRanks().ToList();
                return Ok(ranks);
            }
            catch (Exception ex)
            {
                db.ErrorLog("GetTopRanks", ex.Message, 0);
                throw ex;
            }
        }
        public IHttpActionResult GetAnswersByPoll(int userId,int pollId)
        {
            try
            {

                //var answers = db.GetAnswers_ByPoll(userId,pollId).ToList();
                var answers = db.GetAnswers( userId,  pollId).ToList();
                return Ok(answers);
            }
            catch (Exception ex)
            {
                db.ErrorLog("GetAnswers", ex.Message, userId);
                throw ex;
            }
        }
        [System.Web.Http.HttpPost]
        public IHttpActionResult UpdatePoll(PollMaster poll)
        {
            try
            {
                
                //check the time expriy
              
                if (poll == null)
                {
                    return Ok(new { result = "-1" ,errormsg="invalid poll" });
                }
                var pollStatus= db.GetMatchStatus((int)poll.PollId);
                if(pollStatus!= null &&  pollStatus.ToLower() == "inactive")
                {
                    return Ok(new { result = "-1", errormsg = "Poll Not yet started" });
                }
                if (pollStatus != null &&  pollStatus.ToLower() == "completed")
                {

                    return Ok(new { result = "-1", errormsg = "Poll Already Ended.." });
                }

                var userBalance = db.GetEffectiveBalance((int)poll.UserId, (int)poll.PollId);

                if (userBalance < poll.BetAmount)
                {
                    //lblMsg.Text = $"No credit left, you need { Math.Round((poll.BetAmount ?? 0 - userBalance), 2)} Credit to bet. Contact admin and recharge";
                    return Ok(new { result = "-1", errormsg = $"No credit left, you need  { Math.Round((poll.BetAmount ?? 0 - userBalance), 2)} Credit to bet.Contact admin and recharge" });
                }

                var pollMs = db.GetPollDetails(poll.PollId);
                if (pollMs != null && DateTime.Now < pollMs.DisplayStartTime)
                {

                    return Ok(new { result = "-1", errormsg = "Poll Not yet started" });
                }

                if (pollMs != null && DateTime.Now > pollMs.EndTime)
                {

                    return Ok(new { result = "-1", errormsg = "Poll Already Ended.." });
                }

                var res = db.UpdatePoll(poll.PollId, (int)poll.UserId, poll.PollAns, poll.BetAmount);
                db.ActionLog("UpdatePoll", $" Poll Id - {poll.PollId }, Poll Answer -{ poll.PollAns} , BetAmount - {poll.BetAmount}", poll.UserId);
                return Ok(new { result = "1", errormsg = res });

            }
            catch (Exception ex)
            {
                db.ErrorLog("UpdatePoll", ex.Message, poll.UserId);
                return Ok(new { result = "-1", errormsg = ex.ToString() });
               
            }
            
        }

        [System.Web.Http.HttpPost]
        public IHttpActionResult UpdatePollAns(PollMaster pollParam)
        {
            try
            {

                //if (!IsAdmin)
                //{
                //    return Ok(new { result = "-1", errormsg = "You don't have permission to update poll" });
                //}

                var poll = db.GetPolls(pollParam.PollId).FirstOrDefault();
               

                if (poll == null)
                {
                    return Ok(new { result = "-1", errormsg = "invalid poll" });
                }
                var re = db.UpdatePollAnswer((int)pollParam.PollId, pollParam.PollAns, pollParam.MatchResult);

                db.ProcessPoll((int)pollParam.PollId);
                return Ok(new { result = "1", errormsg = re });
            }
            catch (Exception ex)
            {
                db.ErrorLog("UpdatePoll", ex.Message, 3);
                return Ok(new { result = "-1", errormsg = ex.ToString() });

            }
        }

        public IHttpActionResult GetPointTable()
        {
            try
            {
                return Ok(db.GetPointTable());
            }
            
             catch (Exception ex)
            {
                db.ErrorLog("GetPointTable", ex.Message, 3);
                return Ok(ex);

            }
        }

        [System.Web.Http.HttpPost]
        public IHttpActionResult Procees_Polling(PollMaster pollParam)
        {
            try
            {
                var poll = db.GetPolls(pollParam.PollId).FirstOrDefault();

                if (poll == null)
                {
                    return Ok("-1");
                }
                var result= db.Process_Poll_Transaction((int)pollParam.PollId, pollParam.PollAns, pollParam.MatchResult);
                db.ActionLog("Procees_Polling", $" Procees_Polling is completed for Poll {pollParam.PollId} answer is {pollParam.PollAns } date is {DateTime.Now}.", 3);
                return Ok(result);
            }
            catch (Exception ex)
            {
                db.ErrorLog("Procees_Polling", ex.Message, 3);
                return Ok(ex);

            }
        }
    }

    public class PollMaster
    {
        public int UserId { get; set; }
        public int PollId { get; set; }
        public string PollName { get; set; }
        public System.DateTime StartTime { get; set; }
        public System.DateTime EndTime { get; set; }
        public string PollAns { get; set; }

        public string UserPollAns { get; set; }
        public string Option1 { get; set; }

        public double Option1Percent { get; set; }
        public string Option2 { get; set; }
        public double Option2Percent { get; set; }
        public string Option3 { get; set; }
        public Nullable<int> PollOrder { get; set; }
        public string PollStatus { get; set; }
        public Nullable<System.DateTime> DisplayStartTime { get; set; }
        public Nullable<System.DateTime> DisplayEndTime { get; set; }
        public Nullable<double> BetAmount { get; set; }
        public Nullable<double> UserBetAmount { get; set; }
        public Nullable<double> BetAmountMin { get; set; }
        public Nullable<double> CreditDebitAmount { get; set; }
        public Nullable<int> TransactionType { get; set; }
        public List<PollOptions> PollOptions { get; set; }
        public string MatchResult { get; set; }
        public Boolean IsArrowMark { get; set; }
    }

    public class PollOptions
    {
        public int PollOptionId { get; set; }
        public int PollId { get; set; }
        public string PollOption1 { get; set; }
        public int? DisplayOrder { get; set; }
    }
    public class userVm
    {
        public Nullable<Boolean> IsFirstTimeLogin { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool IsAdmin { get; set; }
        public int UserID { get; set; }
        public double BalanceCredit { get; set; }
        public string  BalanceMessage { get; set; }

        public string YourFavourateTeam { get; set; }
    }
    public partial class GetActivePollAnswers_CommaSeparated_Vm
    {

        public string PollName { get; set; }

        public string PollAns { get; set; }

        public string UserName { get; set; }

        public string TotalVotes { get; set; }

        public string PollStatus { get; set; }

        public int? PollId { get; set; }

    }
    public class TeamsVM
    {
        public int TeamId { get; set; }
        public string Team { get; set; }
        public int? M { get; set; }

        public int? W { get; set; }

        public int? L { get; set; }

        public decimal? NRR { get; set; }

        public int? Pts { get; set; }
        public bool? Status { get; set; }

    }
}