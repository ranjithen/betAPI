﻿using poll_api.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace poll_api.Controllers
{
    public class UsersController : ApiController
    {

        private pollmaster db;
        public UsersController()
        {
            db = new pollmaster();
        }

        [System.Web.Http.HttpPost]
        [Route("api/Users/Authenticate")]
        public IHttpActionResult Authenticate(userVm user)
        {
            try
            {

                var result = db.ValidateUser(user.UserName, user.Password);
                //result.BalanceMessage = "Balance Points: " + db.GetBalanceCredits((int)result.UserID) + "<BR/>Effective Points: " + db.GetEffectiveBalance((int)result.UserID, 0);
                if(result != null)
                db.ActionLog("Login", $"{user.UserName} is Logined to Application , Today is {DateTime.Now}.", result.UserID);
                else
                db.ActionLog("Login", $"{user.UserName} is Login failed , enterd password is {user.Password} , Today is {DateTime.Now}.", 0);
                return Ok(result);
            }
            catch(Exception ex)
            {
                db.ErrorLog("Authenticate", ex.Message, 0);
                throw ex;
            }
        }
        public IHttpActionResult GetBalance(int userId)
        {
            try
            {
              
                var OpeningBal = db.GetBalanceCredits(userId);
                var ClosingBal =   db.GetEffectiveBalance(userId, 0);
                return Ok(new {OpeningBal= OpeningBal, ClosingBal= ClosingBal });
                }
            catch (Exception e)
            {
                db.ErrorLog("GetBalance", e.Message, userId);
                throw e;
            }
        }
        [System.Web.Http.HttpPost]
        [Route("api/Users/Register")]
        public IHttpActionResult Register(userVm user)
        {
            try
            {
                var result = db.ResetPassword(user.UserName, user.Name, user.Password, user.YourFavourateTeam);
                if(result)
                db.ActionLog("Register", $"{user.UserName} is Register to App , Today is {DateTime.Now}.", user.UserID);
                else
                    db.ActionLog("Register", $"{user.UserName} is Registeraton failed to App , Today is {DateTime.Now}.", 0);
                return Ok(result);
            }
            catch (Exception e)
            {
                db.ErrorLog("Register", e.Message, user.UserID);
                throw e;
            }
        }
        [System.Web.Http.HttpPost]
        [Route("api/Users/RegisterUser")]
        public IHttpActionResult RegisterUser(userVm user)
        {
            try
            {
                var result = db.RegisterUser(user.UserName, user.Name, user.Password, user.YourFavourateTeam);
                if (result != null)
                    db.ActionLog("Register", $"{user.UserName} is Register to App , Today is {DateTime.Now}.", user.UserID);
                else
                    db.ActionLog("Register", $"{user.UserName} is Registeraton failed to App , Today is {DateTime.Now}.", 0);
                return Ok(result);
            }
            catch (Exception e)
            {
                db.ErrorLog("Register", e.Message, user.UserID);
                throw e;
            }
        }
       
        [System.Web.Http.HttpPost]
                
        public IHttpActionResult ResetPassword(userVm user)
        {
            try
            {
                var result = db.ChangePassword(user.UserName,  user.Password);
                if(result)
                db.ActionLog("ResetPassword", $"{user.UserName} is opt ResetPassword , date is {DateTime.Now}.", 0);
                else
                    db.ActionLog("ResetPassword", $"{user.UserName} reset password failed , date is {DateTime.Now}.", 0);
                return Ok(result);
            }
            catch (Exception e)
            {
                db.ErrorLog("ResetPassword", e.Message, 0);
                throw e;
            }
        }

        [System.Web.Http.HttpPost]
       
        public IHttpActionResult AddNewUser(userVm user)
        {
            try
            {

                var result = db.AddNewUser(user.UserName, user.BalanceCredit);
                return Ok(result);
            }
            catch (Exception e)
            {
                db.ErrorLog("AddNewUser", e.Message, user.UserID);
                throw e;
            }
        }
        [System.Web.Http.HttpPost]
        public IHttpActionResult UpdateBalance(userVm user)
        {
            try
            {

                var result = db.UpdateBalanceAmount(user.UserName, user.BalanceCredit);
                return Ok(result);
            }
            catch (Exception e)
            {
                db.ErrorLog("UpdateBalance", e.Message, user.UserID);
                throw e;
            }
        }

        public IHttpActionResult GetAllUsers()
        {
            try
            {              
                var users = db.GetAllUsers();
                return Ok(users);
            }
            catch (Exception e)
            {
                db.ErrorLog("GetAllUsers", e.Message, 0);
                throw e;
            }
        }
        [System.Web.Http.HttpPost]
        public IHttpActionResult EditUser(userVm user)
        {
            try
            {

                var result = db.UpdateUser(user.UserID,user.UserName,user.Name,user.Password);
                return Ok(result);
            }
            catch (Exception e)
            {
                db.ErrorLog("EditUser", e.Message, user.UserID);
                throw e;
            }
        }
      

    }
}
