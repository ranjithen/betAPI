﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using poll_api.Data;
using poll_api.Repository;

namespace poll_api.Controllers
{
    public class PlayersController : ApiController
    {
        private vplnet_Entities db = new vplnet_Entities();
        private pollmaster dbMain;
        private pollmaster db1;
        public PlayersController()
        {
            dbMain = new pollmaster();
            db1 = new pollmaster();
        }
       
         private string GetReplaceText(string fileType)
        {
            switch(fileType.ToLower())
            {
                case ".jpeg":
                    return "data:image/jpeg;base64,";
                case ".jpg":
                    return "data:image/jpeg;base64,";
                case "jpeg":
                    return "data:image/jpeg;base64,";
                case "jpg":
                    return "data:image/jpeg;base64,";
                default:
                    return "data:image/png;base64,";
            }
        }
        [ResponseType(typeof(Player))]
        public IHttpActionResult PostPlayer(Player player)
        {
            var result = 0;
            if (!ModelState.IsValid)
            {
                return Ok("000");
            }

            try
            {

                if (!string.IsNullOrEmpty(player.ProfilePic))

                {
                    var fileExtension = Path.GetExtension(player.ProfilePicName);
                    var replaceText = "data:image/png;base64,";
                    string convert = player.ProfilePic.Replace(replaceText, String.Empty);
                    var filePath = System.Web.HttpContext.Current.Server.MapPath("~/Uploads/Players/Season1");

                    string dateAndTime = DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss");
                    var fileName = dateAndTime + fileExtension;

                    if (!Directory.Exists(filePath))
                    {
                        Directory.CreateDirectory(filePath);
                    }

                    byte[] image64 = Convert.FromBase64String(convert);
                    var imgPath = Path.Combine(filePath, fileName);
                    File.WriteAllBytes(imgPath, image64);
                    player.ProfilePicName = fileName;
                    player.Proof = "/Uploads/Players/Season1";
                    result = dbMain.RegisterPlayer(player);
                    if (result > 0)
                    {
                        dbMain.ActionLog("Register Player", $"{player.FirstName} is Register to App (League) , Today is {DateTime.Now}.", player.Pid);
                        return Ok("1");
                    }
                    else
                    {
                        dbMain.ActionLog("Register Player", $"{player.FirstName} is User already exists, Today is {DateTime.Now}.", 0);
                        return Ok("0");
                    }
                }
                else
                {
                    return Ok("-3");
                }

   
            }
            catch (Exception e)
            {
                dbMain.ErrorLog("Register Player", e.Message, player.Pid);
                return Ok(result > 0 ? "-1" : "-2");
            }
           
        }
        public string SaveFile(IFormFile formFile, string path, bool replaceExisting = false)
        {
            string filePath = string.Empty;
            if (formFile.Length > 0)
            {
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                string optimumFileName = Regex.Replace(formFile.FileName.Trim(), "[^A-Za-z0-9_.-]+", "");
                filePath = Path.Combine(path, optimumFileName);
                if (!replaceExisting && File.Exists(filePath))
                {
                    string nameonlypart = Path.GetFileNameWithoutExtension(optimumFileName);
                    string newFilename = string.Concat(nameonlypart, "_", DateTime.Now.ToString("ddMMyyyHHmmss"));
                    filePath = Path.Combine(path, string.Concat(newFilename, Path.GetExtension(optimumFileName)));
                }
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    formFile.CopyToAsync(fileStream).GetAwaiter().GetResult();
                }
            }
            return filePath;
        }
        public IHttpActionResult GetPlayers()
        {

            try
            {

                var result = db1.GetPlayers();

                return Ok(result);
            }
            catch (Exception ex)
            {
                dbMain.ErrorLog("Get Player", ex.Message, 0);
                throw ex;
            }
        }
        public IHttpActionResult GetTeams()
        {

            try
            {

                var result = db1.GetTeams();

                return Ok(result);
            }
            catch (Exception ex)
            {
                dbMain.ErrorLog("Get Teams", ex.Message, 0);
                throw ex;
            }
        }

        public IHttpActionResult GetPageContents()
        {

            try
            {

                var result = db1.GetPageContents();

                return Ok(result);
            }
            catch (Exception ex)
            {
                dbMain.ErrorLog("GetPageContents", ex.Message, 0);
                throw ex;
            }
        }
        private bool PlayerExists(int id)
        {
            return db.Players.Count(e => e.Pid == id) > 0;
        }
        [ResponseType(typeof(Team1))]
        public IHttpActionResult PostTeam(Team1 team)
        {
            var result = 0;
            if (!ModelState.IsValid)
            {
                return Ok("000");
            }

            try
            {

                if (!string.IsNullOrEmpty(team.ProfilePic))

                {
                   
                    var replaceText = "data:image/png;base64,";
                    string convert = team.ProfilePic.Replace(replaceText, String.Empty);
                    var filePath = System.Web.HttpContext.Current.Server.MapPath("~/Uploads/Teams/Season1");

                    var fileName = filePath+"\\"+ team.TeamName + ".png";

                    if (!Directory.Exists(filePath))
                    {
                        Directory.CreateDirectory(filePath);
                    }

                    byte[] image64 = Convert.FromBase64String(convert);
                    var imgPath = Path.Combine(filePath, fileName);
                    File.WriteAllBytes(imgPath, image64);
                    team.Logo = fileName;
                  
                    result = dbMain.RegisterTeam(team);
                    if (result > 0)
                    {
                        dbMain.ActionLog("Register Player", $"{team.TeamName} is Register to App (League) , Today is {DateTime.Now}.", team.TeamId);
                        return Ok("1");
                    }
                    else
                    {
                        dbMain.ActionLog("Register Player", $"{team.TeamName} is User already exists, Today is {DateTime.Now}.", 0);
                        return Ok("0");
                    }
                }
                else
                {
                    return Ok("-3");
                }


            }
            catch (Exception e)
            {
                dbMain.ErrorLog("Register Team", e.Message, team.TeamId);
                return Ok(result > 0 ? "-1" : "-2");
            }

        }


        [ResponseType(typeof(UpdatePlayer))]
        public IHttpActionResult UpdateProfile(UpdatePlayer player)
        {
            var result = 0;
            if (!ModelState.IsValid)
            {
                return Ok("000");
            }

            try
            {
                var usr = db.Players.FirstOrDefault(x => x.Pid == player.Pid);
                if(usr == null)
                {
                    return Ok("-5");
                }
                if (!string.IsNullOrEmpty(player.ProfilePic))

                {



                    var fileExtension = Path.GetExtension(player.ProfilePicName);
                    var replaceText = "data:image/png;base64,";
                    string convert = player.ProfilePic.Replace(replaceText, String.Empty);
                    var filePath = System.Web.HttpContext.Current.Server.MapPath("~/Uploads/Players/Season1");

                    string dateAndTime = DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss");


                    var fileName = dateAndTime + fileExtension;

                    if (!Directory.Exists(filePath))
                    {
                        Directory.CreateDirectory(filePath);

                    }
                    else
                    {
                        var filePathDel = filePath +"/"+ usr.ProfilePic;
                        if (File.Exists(filePathDel))
                        {
                            File.Delete(filePathDel);
                        }
                    }
                  

                    byte[] image64 = Convert.FromBase64String(convert);
                    var imgPath = Path.Combine(filePath, fileName);
                    File.WriteAllBytes(imgPath, image64);
                    usr.ProfilePic = fileName;
                    db.SaveChanges();
                 
                        dbMain.ActionLog("Register Player", $"{player.PlayerName} is Register to App (League) , Today is {DateTime.Now}.", player.Pid);
                        return Ok("1");
                    
                }
                else
                {
                    return Ok("-3");
                }


            }
            catch (Exception e)
            {
                dbMain.ErrorLog("Update Player", e.Message, player.Pid);
                return Ok(result > 0 ? "-1" : "-2");
            }

        }
    }
}